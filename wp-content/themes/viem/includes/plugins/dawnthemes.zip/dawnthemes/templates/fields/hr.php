<?php
defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

echo '<hr/>';